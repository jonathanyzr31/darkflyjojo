# DarkFly-Tool
The latest version of DarkFly tool V.4.0

available Linux and Termux

information:

DarkFly-Tool is an installation tool for installing tools. this tool makes it easy for you. so you don't need to type git clone or look for the github repository. You only have to choose the number. which tool you want to install. there are 530 tools ready for intall. and for those of you who like to have fun. there are 7 SMS spam tools that are ready to use, you just need to choose spam to use the target number. there is a tocopedia DLL, and the DarkFly tool availabe for termux and Linux, even though I only combine it. at least I can satisfy and make it easier for all of you :)

how to install:

**Termux:**

* `pkg install python2`
* `pkg install git`
* `pkg install php`
* `git clone https://github.com/Ranginang67/DarkFly-Tool`
* `cd DarkFly-Tool`
* `python2 install.py`

**Linux:**

* `apt-get install php`
* `apt-get install git`
* `git clone https://github.com/Ranginang67/DarkFly-Tool`
* `cd DarkFly-Tool`
* `python install.py`

**NOTE:**

* `if python install.py is not allowed on Linux. Use this`
* `chmod +x install.py`
* `python install.py`
 
**how to update:**

for update this tool, just do the reinstallation, the first way is to install the Darkfly tools, by reinstalling, the old file will be deleted and replaced with the new one installed.

**indonesia:**

untuk men update tools ini tinggal lakukan cloning ulang dan install lagi seperti pertama kali menginstall, dengan melakukan install ulang, file yang lama akan di ganti dengan yang baru di install, jika sudah di update/install ulang tapi tidak ada perubahan berarti belum gw update lah bego :)

 **Thanks!!**
 
 <hr>
 
|[YouTube](https://www.youtube.com/channel/UCNMD5U02GFeWLqmrl_XSPGQ)
|
